#ifndef DISK_DATABASE_EXCEPTIONS_H
#define DISK_DATABASE_EXCEPTIONS_H

struct DiskDatabaseException {};

#endif