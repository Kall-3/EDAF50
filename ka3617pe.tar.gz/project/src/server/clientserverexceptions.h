#ifndef CLIENT_SERVER_EXCEPTIONS_H
#define CLIENT_SERVER_EXCEPTIONS_H

struct ConnectionClosedException {};
struct ProtocolViolationException {};

#endif
